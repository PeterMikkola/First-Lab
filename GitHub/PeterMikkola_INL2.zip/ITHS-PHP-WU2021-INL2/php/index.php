<html>

<head>

</head>

<body>
    <h1>Uppgifter</h1>

    <h2>G1. Skriva ut på något på sidan</h2>
    <p>Utgå ifrån filen som heter g1.php. Du ska skriva ut valfritt meddelande på sidan med hjälp av php.</p>

    <h2>G2. Landdjur eller vattendjur?</h2>
    <p>Utgå ifrån filen som heter g2.php. Beroende på vilken länk man klickar på kommer variabeln $djur ha olika värden. Skriv ut om det valda djuret är ett vattendjur eller ett landdjur.</p>

    <h2>G3. Skriv ut listan</h2>
    <p>Utgå ifrån filen som heter g3.php. Det finns en array i filen. Skriv klart koden så att alla i arrayen skrivs ut på sidan.</p>

    <h2>G4. Plusräknare</h2>
    <p>Utgå ifrån filen som heter g4.php. Beroende på vilken knapp man trycker på kommer $tal1 och $tal2 innehålla olika tal som kan plussas ihop. Skapa en funktion som tar emot två tal och skriver ut ”Resultatet blev: XX” på sidan. Glöm inte att anropa funktionen.</p>

    <h2>G5. Berätta en saga</h2>
    <p>Utgå ifrån filen som heter g5.php. Där finns ett formulär i vilket man kan fylla i ett djur, ett namn, en färg och en hobby. När man klickar på knappen ska en liten saga skrivas ut och allt man fyllt i ska finnas med, t.ex:<br /><br />
        ”Det var en gång en [djur] som hette [namn]. [namn] älskade att [hobby] och hade favoritfärgen [färg]”</p>

    <h2>VG1. Plusräknare v2</h2>
    <p>Utgå ifrån filen som heter vg1.php. Skapa ett formulär med två input-fält. Ett för tal1 och ett för tal2. Lägg även in en submit-knapp. När man klickar på knappen ska svaret på tal1 + tal2 visas.</p>

    <h2>VG2. Delbart med 3?</h2>
    <p>Utgå ifrån filen som heter vg2.php. Skriv ut alla tal mellan 0 till 100 som är jämnt delbara med 3.</p>

</body>

</html>