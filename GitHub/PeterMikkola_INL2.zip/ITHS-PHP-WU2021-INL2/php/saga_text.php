Det var en gång en <?php echo $_POST["djur"]; ?> som var så stor och ståtlig, att han
        därför kallades för <?php echo $_POST["namn"]; ?>. Hans päls var alldeles gyllene
        och hade en nyans av <?php echo $_POST["farg"]; ?>. Det bästa han visste, som också 
        var hans stora hobby var att <?php echo $_POST["hobby"]; ?>. Det gjorde han
        hela dagarna tills han blev trött och lade sig att sova i sin stora sköna säng.
        Och han var så lycklig!

