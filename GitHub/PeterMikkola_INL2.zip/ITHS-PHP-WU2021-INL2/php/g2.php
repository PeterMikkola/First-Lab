<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;1,300&display=swap" rel="stylesheet">
<title>Exercise 2</title>
</head>
<body>



<main>
<fieldset>
    
<legend>Välj ett djur:</legend>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<a href="?katt">Katt</a>
<a href="?hund">Hund</a>
<a href="?delfin">Delfin</a>
<a href="?kräfta">Kräfta</a>


<br/><br/>

<?php
if (!isset($_GET['katt,hund,delfin,kräfta'])) {
    echo "";
    $katt = '';
    $hund = '';
    $delfin = '';
    $kräfta = '';
      

} else {
    $katt = '';
    $hund = '';
    $delfin = '';
    $kräfta = '';
   
}


if(isset($_GET['katt'])){
    echo "Katten är ett landdjur";
} 
elseif(isset($_GET['hund'])){
    echo "Hunden är ett landdjur";
}
elseif(isset($_GET['delfin'])){
    echo "Delfinen är ett vattendjur";
}
elseif(isset($_GET['kräfta'])){
    echo "Kräftan är ett vattendjur";
} 

  
?> 
</form>

</fieldset>
<br />
<br />
</main>
    </body>
    </html>
