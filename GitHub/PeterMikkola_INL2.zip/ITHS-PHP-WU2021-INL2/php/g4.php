<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;1,300&display=swap" rel="stylesheet">
<title>Exercise 4</title>
</head>
    <style>
    a {
        display: inline-block;
        margin-top: 10px;
        padding: 10px;
        border: 1px solid gray;
        background-color: #ccc;
    }

    a:hover {
        background-color: #ddd;
    }
</style>
<body>

<main>
<fieldset style="margin-bottom: 10px">
<legend>Välj en knapp och se resultatet:</legend>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">


<a href="?button1=true">3 + 6</a>
<a href="?button2=true">2 + 8</a>
<a href="?button3=true">3 + 3</a>

<br /><br />

<?php

if (!isset($_GET['tal1'])) {
    echo "";
} else {
    $tal1 = (int)$_GET['tal1'];
    $tal2 = (int)$_GET['tal2'];
}
    /* Skriv din kod här: */
    function twoInt($tal1, $tal2) {
        return $tal1 + $tal2;
     }

    $tal1 = 3;
    $tal2 = 6;
    $button1 = twoInt($tal1, $tal2);
    if(isset($_GET['button1'])){
        echo ("Summa för första knappen blir: ".$button1);
    } 

    $tal1 = 2;
    $tal2 = 8;
    $button2 = twoInt($tal1, $tal2);
    if(isset($_GET['button2'])){
        echo ("Summa för andra knappen blir: ".$button2); 
    } 



    $tal1 = 3;
    $tal2 = 3;
    $button3 = twoInt($tal1, $tal2);
    if(isset($_GET['button3'])){
        echo ("Summa för tredje knappen blir: ".$button3);
    } 
    ?>
    <br /><br />
<br />  <li><input class="button" value="Rensa" onClick="window.location.reload();"></li> 

    <br /> 
</form>
</fieldset>
<br />
<br />
</main>
</body>
</html>