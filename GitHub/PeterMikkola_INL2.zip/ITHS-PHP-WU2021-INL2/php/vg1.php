<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;1,300&display=swap" rel="stylesheet">
<title>Exercise 5</title>
    
</head>
<body>
<main>
<?php

$tal1Err = $tal2Err = "";
$tal1 = $tal2 = "";

 if(isset($_POST['submit']))  
{  
    $tal1 = (int)$_POST['tal1'];  
    $tal2 = (int)$_POST['tal2'];  
    (int)$sum = $tal1+$tal2;     
//echo "Summan av Tal 1 och Tal 2 är: ".$sum;   
}   

$sum = $_POST['sum'] ?? '';
 
 


// define variables and set to empty valu
function counter($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
/*Lägg in php-koden här */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["tal1"])) {
      $tal1Err = "Fältet får inte lämnas tomt!";
    } else {
      $tal1 = counter($_POST["tal1"]);
      // check if name only contains numbers
      if (!preg_match("@^([1-9][0-9]*)$@", $tal1)) {
      $tal1Err = "Bara siffror tillåtna!";
      }
    }
    if (empty($_POST["tal2"])) {
        $tal2Err = "Fältet får inte lämnas tomt!";
      } else {
        $tal2 = counter($_POST["tal2"]);
        // check if name only contains numbers
        if (!preg_match("@^([1-9][0-9]*)$@", $tal2)) {
        $tal2Err = "Bara siffror tillåtna!";
        }
    } 
  }
?>
<fieldset>
<legend>Addera två tal och se summan:</legend>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <ul>  
<li><label for="tal1">Ange tal 1:</label></li>
<li><input type="text" id="tal1" name="tal1" size="5" value="<?php echo $tal1;?>">
  <span class="error">* <?php echo $tal1Err;?></span></li><br />
  <li><label for="tal2">Ange tal 2:</label></li>
<li><input type="text" id="tal2" name="tal2" size="5" value="<?php echo $tal2;?>">
  <span class="error">* <?php echo $tal2Err;?></span></li><br />
  <?php if(isset($_POST['submit']))  
{  
    $tal1 = (int)$_POST['tal1'];  
    $tal2 = (int)$_POST['tal2'];  
    (int)$sum = $tal1+$tal2;     
echo "Summan av Tal 1 och Tal 2 är: ".$sum;   
} 
 ?>
<br />
<br />
  <li><input type="submit" name="submit" class="submit" value="Summa!" /></li>
  <li><input class="button" value="Rensa" onclick="window.location=''" /></li>
  </ul>
</form>
</fieldset>

<br />

</main>
</body>
</html>