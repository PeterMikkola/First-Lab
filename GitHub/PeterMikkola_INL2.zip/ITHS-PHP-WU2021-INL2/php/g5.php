<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;1,300&display=swap" rel="stylesheet">
<title>Exercise 5</title>
    
</head>
<body>
  <main>
<?php
// define variables and set to empty values
$djurErr = $namnErr = $fargErr = $hobbyErr = "";
$namn = $djur = $farg = $hobby = "";

if(isset($_POST['submit']))  
{  
    $djur = $_POST['djur'];  
    $namn = $_POST['namn'];  
    $farg = $_POST['farg'];  
    $hobby = $_POST['hobby']; //echo "Summan av Tal 1 och Tal 2 är: ".$sum;   
}  

$djur = $_POST['djur'] ?? '';
$namn = $_POST['namn'] ?? '';
$farg = $_POST['farg'] ?? '';
$hobby = $_POST['hobby'] ?? '';

function saga($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["djur"])) {
      $djurErr = "Fältet får inte lämnas tomt!";
    } else {
      $djur = saga($_POST["djur"]);
      // check if name only contains letters and whitespace
      if (!preg_match_all('/[^\d]+/',$djur)) {
        $djurErr = "Bara bokstäver och mellanslag tillåtet!";
      }
    }

        if (empty($_POST["namn"])) {
          $namnErr = "Fältet får inte lämnas tomt!";
        } else {
          $namn = saga($_POST["namn"]);
          // check if name only contains letters and whitespace
          if (!preg_match_all('/[^\d]+/',$namn)) {
            $namnErr = "Bara bokstäver och mellanslag tillåtet!";
          }
        }

            if (empty($_POST["farg"])) {
              $fargErr = "Fältet får inte lämnas tomt!";
            } else {
              $farg = saga($_POST["farg"]);
              // check if name only contains letters and whitespace
              if (!preg_match_all('/[^\d]+/',$farg)) {
                $fargErr = "Bara bokstäver och mellanslag tillåtet!";
              }
            }

                if (empty($_POST["hobby"])) {
                  $hobbyErr = "Fältet får inte lämnas tomt!";
                } else {
                  $hobby = saga($_POST["hobby"]);
                  // check if name only contains letters and whitespace
                  if (!preg_match_all('/[^\d]+/',$hobby)) {
                    $hobbyErr = "Bara bokstäver och mellanslag tillåtet!";
                  }
                
                }

                
                }
      ?>
      <fieldset style="margin-bottom: 10px">
<legend>Fyll i och skriv en saga:</legend>
<!-- <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> -->
<form action="saga_text.php" method="post"> 
<ul>  
<li><label for="djur">Skriv ett djur:</label></li>
<li><input type="text" id="djur" name="djur" value="<?php echo $djur;?>">
  <span class="error">* <?php echo $djurErr;?></span></li><br />
  <li><label for="djur">Skriv ett namn:</label></li>
<li><input type="text" id="namn" name="namn" value="<?php echo $namn;?>">
  <span class="error">* <?php echo $namnErr;?></span></li><br />
  <li><label for="djur">Skriv en färg:</label></li>
<li><input type="text" id="farg" name="farg" value="<?php echo $farg;?>">
  <span class="error">* <?php echo $fargErr;?></span></li><br />
  <li><label for="djur">Skriv en hobby:</label></li>
<li><input type="text" id="hobby" name="hobby" value="<?php echo $hobby;?>">
  <span class="error">* <?php echo $hobbyErr;?></span></li><br />
  <li><input type="submit" name="submit" class="submit" value="Berätta en saga!" /></li>
  <li><input class="button" value="Rensa" onclick="window.location=''" /></li> 
</form>
              </ul>
      </fieldset>
<br />
<fieldset style="margin-top: 3px;">
<legend>Här kommer din saga:</legend>
<br />
<?php
if(isset($_POST['submit'])){
  echo file_get_contents("$saga_text.php");

}
?>
</fieldset>
<br />
<br />

  </main>
</body>
</html>