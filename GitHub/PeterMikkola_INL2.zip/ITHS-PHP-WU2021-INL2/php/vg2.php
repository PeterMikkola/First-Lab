<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"> 
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;1,300&display=swap" rel="stylesheet">
<title>Exercise 5</title>
    
</head>
<body>
<main>
<fieldset>
<legend>Alla siffror mellan noll och hundra som är delbara med tre:</legend>
    <?php
echo "\n";

// The step parameter
//array(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
foreach (range(0, 100, 3) as $number) {
    if(isset($_POST['submit'])){
        echo $number;
    } 
}
?>
<br />
<br />
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<ul><li><input type="submit" name="submit" class="submit" value="Många tal!"></li>
<li><input class="button" value="Rensa" onclick="window.location=''" /></li> 
</ul>
</fieldset>
<br />
<br />
</form>
</main>
</body>
</html>