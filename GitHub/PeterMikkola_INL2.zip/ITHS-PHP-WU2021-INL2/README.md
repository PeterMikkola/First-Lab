# ITHS-PHP-WU2021-INL1

Komma igång

1. Klona Git-repot https://github.com/jonatanhallenberg/ITHS-PHP-WU2021-INL1 till din dator:

<pre><code>git clone https://github.com/jonatanhallenberg/ITHS-PHP-WU2021-INL1</code></pre>

2.	Öppna den klonade mappen i VSCode
3.	Öppna terminalen i VSCode
4.	Starta docker-compose genom att skriva följande i terminalen

<pre><code>docker-compose up -d</code></pre>

5.	Surfa till http://localhost:8081/index.php

Nu är du redo att börja!
