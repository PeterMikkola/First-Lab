var text = "dator";
var nummer = 10;
var sanning = false;
var array = [1, 3, 5, 7, 11, 13, 17, 19];

function add(a, b) {
    return a + b;
}
let sum = add(10, 20);
console.log('Sum:', sum);