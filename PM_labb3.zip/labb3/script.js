var text = "dator";
console.log(chalk.red(text));
var nummer = 10;
console.log(chalk.red(nummer));
var sanning = false;
console.log(chalk.red(sanning));

var array = [1, 3, 5, 7, 11, 13, 17, 19];

function add(a, b) {
    return a + b;
}
let sum = add(10, 20);
console.log('Sum:', sum);

for (var i = 0; i < array.length; i++) {
    console.log(array[i]);
}
let x = 30
let y = 20
if (y > x) {
    console.log('y is less than x');

 } else if (x < y) {
      console.log('x is greater than y');

 } else {
    console.log('x is equal to y');
 }
