/*const express = require("express");
const app = express();
const port = 3000;

app.get("/", )
console.log("Node funkar som det ska!");*/

const chalk = require('chalk');
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Go away hacker!')
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})