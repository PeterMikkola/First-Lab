<?php

echo "Hello world!";
echo PHP_VERSION;

echo 'PHP version: ' . phpversion();
?>