<?php

if(isset($_POST['submit'])) {

  echo $username = $_POST['username'];           
  echo $password = $_POST['password'];           

                
}              
      ?>
      <?php if(isset($_POST['submit'])) {
    echo "It's working";
} ?>